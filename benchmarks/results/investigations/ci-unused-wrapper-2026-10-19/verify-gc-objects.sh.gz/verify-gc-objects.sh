#!/usr/bin/env bash
set -u
stage=$1
workspace=/tmp/parallel-gc-ci-repair-20261019-IuvW1e
clang_compiler=/mnt/gvfs/third-party2/llvm-fb/ade27f36666476c87c4b1c4dc59556382205b7c3/21/platform010-aarch64/8a5abe5/bin/clang
total_failures=0
for compiler_kind in gcc clang; do
    compiler=gcc
    if [[ "$compiler_kind" == clang ]]; then compiler=$clang_compiler; fi
    for item in gil-release:/tmp/parallel-gc-benchmarks-complete-20261016-ntQPAW/candidate-gil ft-release:/tmp/parallel-gc-benchmarks-complete-20261016-ntQPAW/candidate-ft gil-debug:/data/users/alexturner/parallel_gc/build-ci-check-gil-on ft-debug:/data/users/alexturner/parallel_gc/build-fidelity-ft; do
        label=${item%%:*}
        config=${item#*:}
        output="$workspace/$stage-$compiler_kind-$label"
        mkdir "$output"
        "$compiler" --version > "$output/compiler.txt"
        flags=(-g0 -std=c11 -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -Werror=unused-function -Werror=unused-variable -DPy_BUILD_CORE -I"$config" -IInclude -IInclude/internal -IInclude/internal/mimalloc)
        if [[ "$label" == *release ]]; then flags+=(-O3 -DNDEBUG); else flags+=(-Og); fi
        failures=0
        for object in gc gc_free_threading gc_parallel gc_free_threading_parallel; do
            if "$compiler" -c "${flags[@]}" "Python/$object.c" -o "$output/$object.o" > "$output/$object.log" 2>&1; then
                echo "$compiler_kind $label $object $stage PASS"
            else
                echo "$compiler_kind $label $object $stage FAIL"
                failures=$((failures + 1))
            fi
        done
        echo "$compiler_kind $label failures=$failures"
        total_failures=$((total_failures + failures))
    done
done
echo "total_failures=$total_failures"
if [[ "$stage" == after && "$total_failures" != 0 ]]; then exit 1; fi
