"""Cross-check the completed campaign without importing its analysis tool."""

import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics

import pyperf


root = Path('/tmp/parallel-gc-pyperformance-rigorous-6a93Gj')
campaign = root / 'full-v4/ft-enabled'
record = json.loads((campaign / 'campaign.json').read_text())
report = json.loads((root / 'analysis-ft-enabled/ft-enabled.json').read_text())
assert record['order'] == ['baseline', 'candidate', 'candidate', 'baseline']
assert report['runtime_mode'] == 'enabled' and report['build_mode'] == 'ft'
assert report['program_count'] == 100 and report['result_count'] == 127
for filename, digest in record['results'].items():
    assert hashlib.sha256((campaign / filename).read_bytes()).hexdigest() == digest
print('All seven recorded result/comparison digests match.')

suites = []
environments = []
for run in record['runs']:
    suite = pyperf.BenchmarkSuite.load(str(campaign / run['result']))
    assert len(suite.get_benchmarks()) == 127
    execution = json.loads((campaign / run['result']).with_suffix('.execution.json').read_text())
    assert execution['dependency_installation'] is False
    assert len(execution['programs']) == 100
    assert execution['programs'] == run['programs']
    environments.append(execution['environment']['packages'])
    measured = values = 0
    for benchmark in suite:
        assert benchmark.get_unit() == 'second'
        for saved_run in benchmark.get_runs():
            metadata = saved_run.get_metadata()
            assert metadata['parallel_gc_build_gil_disabled'] is True
            assert metadata['parallel_gc_runtime_gil_enabled'] is False
            assert metadata['parallel_gc_enabled'] is True
            assert metadata['parallel_gc_available'] is True
            assert type(metadata['parallel_gc_hook_entries']) is int
            assert metadata['parallel_gc_hook_entries'] > 0
            measured += bool(saved_run.values)
            values += len(saved_run.values)
    print(run['result'], len(execution['programs']), 'programs,', len(suite.get_benchmarks()),
          'named results,', measured, 'measured run records,', values, 'values')
    suites.append(suite)
assert all(environment == environments[0] for environment in environments)
print('Dependency versions and direct-URL inventories match across all four legs.')

ratios = []
for row in report['rows']:
    means = [statistics.fmean(suite.get_benchmark(row['benchmark']).get_values())
             for suite in suites]
    baseline = (means[0] + means[3]) / 2
    candidate = (means[1] + means[2]) / 2
    ratio = candidate / baseline
    assert math.isclose(row['time_ratio'], ratio, rel_tol=1e-12)
    assert math.isclose(row['time_change_pct'], 100 * (ratio - 1), abs_tol=1e-10)
    for observed, actual in zip(row['half_time_changes_pct'],
                               (100 * (means[1] / means[0] - 1),
                                100 * (means[2] / means[3] - 1))):
        assert math.isclose(observed, actual, abs_tol=1e-10)
    ratios.append(ratio)
geomean_change = 100 * (math.exp(sum(math.log(ratio) for ratio in ratios) / len(ratios)) - 1)
assert math.isclose(report['geomean_time_change_pct'], geomean_change, abs_tol=1e-10)
print('All 127 time ratios, both halves and geometric mean match raw-leg arithmetic.')
print('Geometric mean execution-time change:', geomean_change)
print('Verified UTC:', datetime.datetime.now(datetime.timezone.utc).isoformat())
